<?php

namespace Alura\DesignPattern;

interface Command
{
    public function execute();
}